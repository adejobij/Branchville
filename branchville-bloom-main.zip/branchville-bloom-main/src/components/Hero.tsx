
import { ShoppingBasket, LeafyGreen } from "lucide-react";

const Hero = () => {
  return (
    <div className="bg-gradient-to-b from-primary-50 to-white py-8">
      <div className="container px-4 mx-auto">
        <div className="text-center">
          <h1 className="text-5xl font-bold text-primary-800 mb-4 animate-float">
            Summers Wellness Farms
          </h1>
          <div className="flex justify-center items-center mb-6">
            <ShoppingBasket className="w-16 h-16 text-primary-600" />
            <LeafyGreen className="w-12 h-12 text-primary-600 -ml-2 mt-2" />
          </div>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Discover the connection between nutrition, mental health, and sustainability
          </p>
        </div>
      </div>
    </div>
  );
};

export default Hero;
