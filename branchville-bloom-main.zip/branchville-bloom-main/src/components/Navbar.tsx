
import { useState } from "react";
import { LeafyGreen } from "lucide-react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { SignedIn, SignedOut, UserButton } from "@clerk/clerk-react";
import { Button } from "./ui/button";

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  const isActive = (path: string) => {
    return location.pathname === path ? "text-primary-600" : "text-gray-600";
  };

  return (
    <nav className="fixed w-full bg-white/80 backdrop-blur-md z-50 shadow-sm">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="flex items-center">
            <LeafyGreen className="h-8 w-8 text-primary-600" />
            <span className="ml-2 text-xl font-bold text-primary-800">Branchville</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <Link to="/" className={`hover:text-primary-600 transition-colors ${isActive('/')}`}>
              Dashboard
            </Link>
            <Link to="/sustainable-living" className={`hover:text-primary-600 transition-colors ${isActive('/sustainable-living')}`}>
              Sustainable Living
            </Link>
            <Link to="/healthy-living" className={`hover:text-primary-600 transition-colors ${isActive('/healthy-living')}`}>
              Healthy Living
            </Link>
            <Link to="/challenges" className={`hover:text-primary-600 transition-colors ${isActive('/challenges')}`}>
              Challenges
            </Link>
            <Link to="/farm-tours" className={`hover:text-primary-600 transition-colors ${isActive('/farm-tours')}`}>
              Farm Tours
            </Link>
            
            <SignedIn>
              <UserButton afterSignOutUrl="/" />
            </SignedIn>
            <SignedOut>
              <Button 
                onClick={() => navigate('/sign-in')}
                className="bg-primary-600 text-white hover:bg-primary-700 transition-colors"
              >
                Get Started
              </Button>
            </SignedOut>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden"
            onClick={() => setIsOpen(!isOpen)}
          >
            <svg
              className="h-6 w-6 text-gray-600"
              fill="none"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              {isOpen ? (
                <path d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path d="M4 6h16M4 12h16M4 18h16" />
              )}
            </svg>
          </button>
        </div>

        {/* Mobile Menu */}
        {isOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1">
              <Link
                to="/"
                className={`block px-3 py-2 hover:text-primary-600 transition-colors ${isActive('/')}`}
              >
                Dashboard
              </Link>
              <Link
                to="/sustainable-living"
                className={`block px-3 py-2 hover:text-primary-600 transition-colors ${isActive('/sustainable-living')}`}
              >
                Sustainable Living
              </Link>
              <Link
                to="/healthy-living"
                className={`block px-3 py-2 hover:text-primary-600 transition-colors ${isActive('/healthy-living')}`}
              >
                Healthy Living
              </Link>
              <Link
                to="/challenges"
                className={`block px-3 py-2 hover:text-primary-600 transition-colors ${isActive('/challenges')}`}
              >
                Challenges
              </Link>
              <Link
                to="/farm-tours"
                className={`block px-3 py-2 hover:text-primary-600 transition-colors ${isActive('/farm-tours')}`}
              >
                Farm Tours
              </Link>
              <SignedIn>
                <UserButton afterSignOutUrl="/" />
              </SignedIn>
              <SignedOut>
                <Button 
                  onClick={() => navigate('/sign-in')}
                  className="w-full text-left px-3 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 transition-colors"
                >
                  Get Started
                </Button>
              </SignedOut>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
