import { LeafyGreen } from "lucide-react";
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "./ui/carousel";
import { Badge } from "./ui/badge";

interface FoodItem {
  name: string;
  benefits: string[];
  moodBoost: string;
  image: string;
}

const foodSuggestions: FoodItem[] = [
  {
    name: "Green Smoothie Bowl",
    benefits: ["High in antioxidants", "Boosts energy", "Rich in fiber"],
    moodBoost: "Energy & Focus",
    image: "https://images.unsplash.com/photo-1649972904349-6e44c42644a7"
  },
  {
    name: "Omega-3 Rich Salmon",
    benefits: ["Brain health", "Anti-inflammatory", "Protein-rich"],
    moodBoost: "Mental Clarity",
    image: "https://images.unsplash.com/photo-1501854140801-50d01698950b"
  },
  {
    name: "Berry Parfait",
    benefits: ["Vitamin C", "Antioxidants", "Probiotics"],
    moodBoost: "Happiness",
    image: "https://images.unsplash.com/photo-1472396961693-142e6e269027"
  }
];

const FoodSuggestions = () => {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="flex items-center gap-4 mb-6">
        <LeafyGreen className="w-6 h-6 text-primary-600" />
        <h3 className="text-xl font-semibold">Recommended Foods</h3>
      </div>
      <Carousel className="w-full max-w-xl mx-auto">
        <CarouselContent>
          {foodSuggestions.map((food, index) => (
            <CarouselItem key={index}>
              <div className="bg-white rounded-lg overflow-hidden">
                <img
                  src={food.image}
                  alt={food.name}
                  className="w-full h-48 object-cover"
                />
                <div className="p-4">
                  <h4 className="text-lg font-semibold mb-2">{food.name}</h4>
                  <p className="text-sm text-muted-foreground mb-2">
                    Mood Boost: {food.moodBoost}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {food.benefits.map((benefit, i) => (
                      <Badge key={i} variant="secondary">
                        {benefit}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            </CarouselItem>
          ))}
        </CarouselContent>
        <CarouselPrevious />
        <CarouselNext />
      </Carousel>
    </div>
  );
};

export default FoodSuggestions;