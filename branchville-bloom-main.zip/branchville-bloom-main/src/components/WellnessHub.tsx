
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { LeafyGreen, Brain, Heart } from "lucide-react";
import { Link } from "react-router-dom";

const WellnessHub = () => {
  return (
    <div className="container mx-auto px-4 mb-8">
      <div className="grid grid-cols-3 gap-4">
        <Link to="/sustainable-living" className="h-full">
          <Card className="p-6 hover:shadow-lg transition-shadow cursor-pointer h-full">
            <div className="flex justify-center mb-4">
              <LeafyGreen className="w-12 h-12 text-primary-600" />
            </div>
            <h3 className="text-xl font-semibold mb-2 text-center">Sustainable Living</h3>
            <p className="text-gray-600 text-center">
              Discover eco-friendly food choices and nutrition tips for a sustainable lifestyle
            </p>
          </Card>
        </Link>

        <Link to="/healthy-living" className="h-full">
          <Card className="p-6 hover:shadow-lg transition-shadow cursor-pointer h-full">
            <div className="flex justify-center mb-4">
              <Heart className="w-12 h-12 text-primary-600" />
            </div>
            <h3 className="text-xl font-semibold mb-2 text-center">Healthy Living</h3>
            <p className="text-gray-600 text-center">
              Track your mood, journal your wellness journey, and connect with the community
            </p>
          </Card>
        </Link>

        <Link to="/challenges" className="h-full">
          <Card className="p-6 hover:shadow-lg transition-shadow cursor-pointer h-full">
            <div className="flex justify-center mb-4">
              <Brain className="w-12 h-12 text-primary-600" />
            </div>
            <h3 className="text-xl font-semibold mb-2 text-center">Wellness Challenges</h3>
            <p className="text-gray-600 text-center">
              Join exciting challenges and track your progress towards better health
            </p>
          </Card>
        </Link>
      </div>
    </div>
  );
};

export default WellnessHub;
