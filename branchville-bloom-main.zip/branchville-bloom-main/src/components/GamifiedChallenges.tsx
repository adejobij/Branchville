import { Trophy, Award, Star } from "lucide-react";
import { Progress } from "./ui/progress";
import { Badge } from "./ui/badge";
import { Card } from "./ui/card";

interface Challenge {
  id: string;
  title: string;
  description: string;
  progress: number;
  points: number;
  deadline: string;
}

const challenges: Challenge[] = [
  {
    id: "1",
    title: "Green Eating Week",
    description: "Eat a serving of leafy greens with each meal",
    progress: 60,
    points: 100,
    deadline: "2 days left"
  },
  {
    id: "2",
    title: "Mindful Meals",
    description: "Log your mood before and after eating",
    progress: 40,
    points: 75,
    deadline: "3 days left"
  },
  {
    id: "3",
    title: "Water Champion",
    description: "Drink 8 glasses of water daily",
    progress: 80,
    points: 50,
    deadline: "1 day left"
  }
];

const GamifiedChallenges = () => {
  return (
    <div className="space-y-6">
      {/* Points Overview */}
      <div className="flex items-center justify-between bg-white rounded-lg p-4 shadow-md">
        <div className="flex items-center gap-3">
          <Trophy className="w-8 h-8 text-primary-600" />
          <div>
            <h3 className="text-lg font-semibold">Total Points</h3>
            <p className="text-2xl font-bold text-primary-600">750</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Badge variant="secondary" className="flex items-center gap-1">
            <Star className="w-4 h-4" />
            Level 5
          </Badge>
          <Badge variant="outline" className="flex items-center gap-1">
            <Award className="w-4 h-4" />
            3 Badges
          </Badge>
        </div>
      </div>

      {/* Active Challenges */}
      <div className="space-y-4">
        <h3 className="text-xl font-semibold">Active Challenges</h3>
        <div className="grid gap-4">
          {challenges.map((challenge) => (
            <Card key={challenge.id} className="p-4 hover:shadow-lg transition-shadow">
              <div className="space-y-3">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-semibold">{challenge.title}</h4>
                    <p className="text-sm text-muted-foreground">{challenge.description}</p>
                  </div>
                  <Badge variant="secondary">{challenge.points} pts</Badge>
                </div>
                <Progress value={challenge.progress} className="h-2" />
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">{challenge.progress}% complete</span>
                  <span className="text-primary-600 font-medium">{challenge.deadline}</span>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* Upcoming Rewards */}
      <div className="bg-white rounded-lg p-4 shadow-md">
        <h3 className="text-lg font-semibold mb-3">Next Reward</h3>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-primary-100 p-2 rounded-full">
              <Trophy className="w-6 h-6 text-primary-600" />
            </div>
            <div>
              <p className="font-medium">Pizza Lunch Reward</p>
              <p className="text-sm text-muted-foreground">250 points needed</p>
            </div>
          </div>
          <Progress value={75} className="w-24" />
        </div>
      </div>
    </div>
  );
};

export default GamifiedChallenges;