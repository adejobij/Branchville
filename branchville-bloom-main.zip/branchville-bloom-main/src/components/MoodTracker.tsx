
import { useState } from "react";
import { Progress } from "./ui/progress";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Calendar } from "./ui/calendar";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogTrigger,
  DialogFooter
} from "./ui/dialog";
import { format } from "date-fns";
import { Heart, CalendarDays, Plus, SmilePlus } from "lucide-react";
import EmojiPicker, { EmojiClickData } from "emoji-picker-react";

interface JournalEntry {
  id: string;
  date: Date;
  mood: string;
  moodLevel: number;
  text: string;
  emoji: string;
}

const MoodTracker = () => {
  const [moodLevel, setMoodLevel] = useState(75);
  const [selectedMood, setSelectedMood] = useState<string>("happy");
  const [showJournalModal, setShowJournalModal] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [journalText, setJournalText] = useState("");
  const [selectedEmoji, setSelectedEmoji] = useState("😊");
  const [entries, setEntries] = useState<JournalEntry[]>([]);

  const handleEmojiClick = (emojiData: EmojiClickData) => {
    setSelectedEmoji(emojiData.emoji);
    setShowEmojiPicker(false);
  };

  const handleSaveEntry = () => {
    const newEntry: JournalEntry = {
      id: Date.now().toString(),
      date: selectedDate,
      mood: selectedMood,
      moodLevel,
      text: journalText,
      emoji: selectedEmoji,
    };
    
    setEntries([...entries, newEntry]);
    setJournalText("");
    setShowJournalModal(false);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex items-center gap-4 mb-4">
          <Heart className="w-6 h-6 text-primary-600" />
          <h3 className="text-xl font-semibold">Today's Mood</h3>
        </div>
        <div className="space-y-4">
          <div className="flex gap-2">
            {["happy", "neutral", "sad"].map((mood) => (
              <Badge
                key={mood}
                variant={selectedMood === mood ? "default" : "outline"}
                className="cursor-pointer"
                onClick={() => setSelectedMood(mood)}
              >
                {mood.charAt(0).toUpperCase() + mood.slice(1)}
              </Badge>
            ))}
          </div>
          <Progress value={moodLevel} className="w-full" />
          <input
            type="range"
            min="0"
            max="100"
            value={moodLevel}
            onChange={(e) => setMoodLevel(parseInt(e.target.value))}
            className="w-full"
          />
        </div>
      </div>

      {/* Journal Entries Section */}
      <Dialog open={showJournalModal} onOpenChange={setShowJournalModal}>
        <DialogTrigger asChild>
          <Button className="w-full gap-2">
            <Plus className="w-4 h-4" /> Add Journal Entry
          </Button>
        </DialogTrigger>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>New Journal Entry</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <label>Date</label>
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={(date) => date && setSelectedDate(date)}
                className="rounded-md border"
              />
            </div>
            <div className="grid gap-2">
              <label>How are you feeling?</label>
              <div className="flex items-center gap-2">
                <div className="text-2xl">{selectedEmoji}</div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                >
                  <SmilePlus className="w-4 h-4" />
                </Button>
              </div>
              {showEmojiPicker && (
                <div className="absolute z-50 mt-2">
                  <EmojiPicker onEmojiClick={handleEmojiClick} />
                </div>
              )}
            </div>
            <div className="grid gap-2">
              <label>Journal Entry</label>
              <Textarea
                value={journalText}
                onChange={(e) => setJournalText(e.target.value)}
                placeholder="Write your thoughts..."
                className="h-32"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowJournalModal(false)}>
              Cancel
            </Button>
            <Button onClick={handleSaveEntry}>Save Entry</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Recent Entries */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <h4 className="font-semibold mb-4 flex items-center gap-2">
          <CalendarDays className="w-5 h-5" />
          Recent Entries
        </h4>
        <div className="space-y-4">
          {entries.map((entry) => (
            <div key={entry.id} className="border rounded-lg p-4">
              <div className="flex justify-between items-start mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-xl">{entry.emoji}</span>
                  <span className="text-sm text-muted-foreground">
                    {format(entry.date, "PPP")}
                  </span>
                </div>
                <Badge variant="outline">{entry.mood}</Badge>
              </div>
              <p className="text-sm">{entry.text}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default MoodTracker;
