import { Brain } from "lucide-react";
import { Badge } from "./ui/badge";

const BrainHealthTips = () => {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="flex items-center gap-4 mb-4">
        <Brain className="w-6 h-6 text-primary-600" />
        <h3 className="text-xl font-semibold">Brain Health Tips</h3>
      </div>
      <ul className="space-y-3">
        <li className="flex items-center gap-2">
          <Badge variant="outline">Tip</Badge>
          Stay hydrated for better cognitive function
        </li>
        <li className="flex items-center gap-2">
          <Badge variant="outline">Tip</Badge>
          Practice mindful eating to improve digestion
        </li>
        <li className="flex items-center gap-2">
          <Badge variant="outline">Tip</Badge>
          Include omega-3 rich foods for brain health
        </li>
      </ul>
    </div>
  );
};

export default BrainHealthTips;