import { Heart, MessageCircle, Share2 } from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Avatar } from "./ui/avatar";

interface Post {
  id: number;
  author: string;
  avatar: string;
  content: string;
  likes: number;
  comments: number;
  image?: string;
}

const posts: Post[] = [
  {
    id: 1,
    author: "Sarah Johnson",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330",
    content: "Just completed my 30-day wellness challenge! Feeling amazing and energized! 🌟",
    likes: 24,
    comments: 5,
    image: "https://images.unsplash.com/photo-1448387473223-5c37445527e7"
  },
  {
    id: 2,
    author: "Mike Chen",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d",
    content: "Today's healthy breakfast bowl packed with superfoods! 🥗",
    likes: 18,
    comments: 3,
    image: "https://images.unsplash.com/photo-1511690743698-d9d85f2fbf38"
  }
];

const CommunityFeed = () => {
  return (
    <div className="space-y-6 p-4">
      <h2 className="text-2xl font-bold text-primary-800 mb-6">Community Feed</h2>
      
      {posts.map((post) => (
        <Card key={post.id} className="p-4">
          <div className="flex items-center gap-3 mb-4">
            <Avatar>
              <img src={post.avatar} alt={post.author} className="w-10 h-10 rounded-full" />
            </Avatar>
            <div>
              <h3 className="font-semibold">{post.author}</h3>
            </div>
          </div>
          
          <p className="mb-4">{post.content}</p>
          
          {post.image && (
            <img
              src={post.image}
              alt="Post content"
              className="w-full h-48 object-cover rounded-lg mb-4"
            />
          )}
          
          <div className="flex gap-4">
            <Button variant="ghost" size="sm" className="flex items-center gap-2">
              <Heart className="w-4 h-4" />
              {post.likes}
            </Button>
            <Button variant="ghost" size="sm" className="flex items-center gap-2">
              <MessageCircle className="w-4 h-4" />
              {post.comments}
            </Button>
            <Button variant="ghost" size="sm" className="flex items-center gap-2">
              <Share2 className="w-4 h-4" />
              Share
            </Button>
          </div>
        </Card>
      ))}
    </div>
  );
};

export default CommunityFeed;