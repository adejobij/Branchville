
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import ChatWidget from "./components/ChatWidget";
import Index from "./pages/Index";
import Challenges from "./pages/Challenges";
import FarmTours from "./pages/FarmTours";
import SustainableLiving from "./pages/SustainableLiving";
import HealthyLiving from "./pages/HealthyLiving";
import NotFound from "./pages/NotFound";
import SignIn from "./pages/SignIn";
import SignUp from "./pages/SignUp";

const App = () => {
  const queryClient = new QueryClient();

  return (
    <BrowserRouter>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/sustainable-living" element={<SustainableLiving />} />
            <Route path="/healthy-living" element={<HealthyLiving />} />
            <Route path="/challenges" element={<Challenges />} />
            <Route path="/farm-tours" element={<FarmTours />} />
            <Route path="/sign-in" element={<SignIn />} />
            <Route path="/sign-up" element={<SignUp />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
          <ChatWidget />
        </TooltipProvider>
      </QueryClientProvider>
    </BrowserRouter>
  );
};

export default App;
