import { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import Navbar from "../components/Navbar";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/components/ui/use-toast";
import { Camera, Info } from "lucide-react";

const FarmTours = () => {
  const { toast } = useToast();
  const mountRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const [activeHotspot, setActiveHotspot] = useState<string | null>(null);

  useEffect(() => {
    if (!mountRef.current) return;

    // Scene setup
    const scene = new THREE.Scene();
    sceneRef.current = scene;

    // Camera setup
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.z = 5;
    cameraRef.current = camera;

    // Renderer setup
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setClearColor(0xf0fdf4); // Light green background
    mountRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Add a simple greenhouse model (placeholder)
    const geometry = new THREE.BoxGeometry(2, 1.5, 2);
    const material = new THREE.MeshPhongMaterial({ 
      color: 0x88c580,
      transparent: true,
      opacity: 0.8
    });
    const greenhouse = new THREE.Mesh(geometry, material);
    scene.add(greenhouse);

    // Add lighting
    const ambientLight = new THREE.AmbientLight(0x404040);
    scene.add(ambientLight);
    
    const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
    directionalLight.position.set(1, 1, 1);
    scene.add(directionalLight);

    // Animation loop
    const animate = () => {
      requestAnimationFrame(animate);
      greenhouse.rotation.y += 0.005;
      renderer.render(scene, camera);
    };
    animate();

    // Handle window resize
    const handleResize = () => {
      if (!mountRef.current) return;
      const width = window.innerWidth;
      const height = window.innerHeight;
      
      if (cameraRef.current) {
        cameraRef.current.aspect = width / height;
        cameraRef.current.updateProjectionMatrix();
      }
      
      if (rendererRef.current) {
        rendererRef.current.setSize(width, height);
      }
    };
    window.addEventListener('resize', handleResize);

    // Cleanup
    return () => {
      window.removeEventListener('resize', handleResize);
      mountRef.current?.removeChild(renderer.domElement);
      scene.clear();
    };
  }, []);

  const handleHotspotClick = (hotspotId: string) => {
    setActiveHotspot(hotspotId);
    toast({
      title: "Hotspot Activated",
      description: `You've discovered the ${hotspotId}! Learn about sustainable farming practices.`,
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-primary-50 to-white">
      <Navbar />
      <div className="relative">
        {/* 3D Scene Container */}
        <div ref={mountRef} className="w-full h-[calc(100vh-4rem)]" />

        {/* Overlay UI */}
        <div className="absolute top-4 left-4 z-10 space-y-4">
          <Card className="p-4 bg-white/90 backdrop-blur-sm">
            <h2 className="text-xl font-bold text-primary-800 mb-2">Virtual Farm Tour</h2>
            <p className="text-sm text-gray-600 mb-4">
              Explore our sustainable farm in 3D. Click on hotspots to learn more.
            </p>
            <div className="flex gap-2">
              <Badge variant="secondary" className="flex items-center gap-1">
                <Camera className="w-4 h-4" />
                3D View
              </Badge>
              <Badge variant="outline" className="flex items-center gap-1">
                <Info className="w-4 h-4" />
                4 Hotspots
              </Badge>
            </div>
          </Card>

          <div className="space-y-2">
            <Button 
              variant="secondary"
              className="w-full"
              onClick={() => handleHotspotClick('Greenhouse')}
            >
              Greenhouse
            </Button>
            <Button 
              variant="secondary"
              className="w-full"
              onClick={() => handleHotspotClick('Compost Area')}
            >
              Compost Area
            </Button>
            <Button 
              variant="secondary"
              className="w-full"
              onClick={() => handleHotspotClick('Garden Beds')}
            >
              Garden Beds
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FarmTours;