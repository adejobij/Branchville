
import Navbar from "../components/Navbar";
import Hero from "../components/Hero";
import WellnessHub from "../components/WellnessHub";

const Index = () => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-primary-50 to-white">
      <Navbar />
      <div className="pt-24">
        <Hero />
        <WellnessHub />
      </div>
    </div>
  );
};

export default Index;
