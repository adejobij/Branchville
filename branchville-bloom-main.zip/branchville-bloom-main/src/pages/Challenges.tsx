import GamifiedChallenges from "../components/GamifiedChallenges";
import Navbar from "../components/Navbar";

const Challenges = () => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-primary-50 to-white pt-20">
      <Navbar />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-primary-800 mb-8">Wellness Challenges</h1>
        <GamifiedChallenges />
      </div>
    </div>
  );
};

export default Challenges;