
import Navbar from "../components/Navbar";
import FoodSuggestions from "../components/FoodSuggestions";
import BrainHealthTips from "../components/BrainHealthTips";

const SustainableLiving = () => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-primary-50 to-white">
      <Navbar />
      <div className="container mx-auto px-4 pt-20">
        <h1 className="text-3xl font-bold text-primary-800 mb-8">Sustainable Living</h1>
        <div className="space-y-8">
          <FoodSuggestions />
          <BrainHealthTips />
        </div>
      </div>
    </div>
  );
};

export default SustainableLiving;
