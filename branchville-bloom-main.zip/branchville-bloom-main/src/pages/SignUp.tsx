
import { SignUp } from "@clerk/clerk-react";

const SignUpPage = () => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-primary-50 to-white flex items-center justify-center">
      <SignUp
        appearance={{
          elements: {
            card: "bg-white shadow-xl",
            headerTitle: "text-primary-800 text-2xl font-bold",
            headerSubtitle: "text-gray-600",
            socialButtonsBlockButton: "bg-white border border-gray-300 hover:bg-gray-50",
            formButtonPrimary: "bg-primary-600 hover:bg-primary-700",
            footerActionLink: "text-primary-600 hover:text-primary-700"
          },
        }}
        routing="path"
        path="/sign-up"
        signInUrl="/sign-in"
        afterSignUpUrl="/"
      />
    </div>
  );
};

export default SignUpPage;
