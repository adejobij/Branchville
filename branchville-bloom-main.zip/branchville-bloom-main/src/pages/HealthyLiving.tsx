
import Navbar from "../components/Navbar";
import MoodTracker from "../components/MoodTracker";
import CommunityFeed from "../components/CommunityFeed";

const HealthyLiving = () => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-primary-50 to-white">
      <Navbar />
      <div className="container mx-auto px-4 pt-20">
        <h1 className="text-3xl font-bold text-primary-800 mb-8">Healthy Living</h1>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-8">
            <MoodTracker />
          </div>
          <div>
            <CommunityFeed />
          </div>
        </div>
      </div>
    </div>
  );
};

export default HealthyLiving;
